#pragma once

#include <cstdint>
#include <cmath>
#include <cstring>
#include <optional>
#include <stdexcept>
#include <string>
#include <variant>
#include <vector>

namespace demo {

enum class DataType : std::uint16_t {
    Bool = 1,
    Int32 = 2,
    UInt32 = 3,
    Int64 = 4,
    UInt64 = 5,
    Float32 = 6,
    Float64 = 7,
};

enum class PointStatus : std::uint16_t {
    NotConnected = 0,
    Bad = 1,
    Good = 2,
};

using Value = std::variant<bool, std::int32_t, std::uint32_t, std::int64_t,
                           std::uint64_t, float, double>;

inline std::string toString(DataType type) {
    switch (type) {
    case DataType::Bool: return "BOOL";
    case DataType::Int32: return "INT32";
    case DataType::UInt32: return "UINT32";
    case DataType::Int64: return "INT64";
    case DataType::UInt64: return "UINT64";
    case DataType::Float32: return "FLOAT32";
    case DataType::Float64: return "FLOAT64";
    }
    return "UNKNOWN";
}

inline DataType parseDataType(const std::string &text) {
    if (text == "BOOL") return DataType::Bool;
    if (text == "INT32") return DataType::Int32;
    if (text == "UINT32") return DataType::UInt32;
    if (text == "INT64") return DataType::Int64;
    if (text == "UINT64") return DataType::UInt64;
    if (text == "FLOAT32") return DataType::Float32;
    if (text == "FLOAT64" || text == "DOUBLE") return DataType::Float64;
    throw std::runtime_error("unsupported data type: " + text);
}

inline std::string valueToString(const Value &value) {
    return std::visit([](auto v) {
        using T = decltype(v);
        if constexpr (std::is_same_v<T, bool>) return std::string(v ? "true" : "false");
        else if constexpr (std::is_floating_point_v<T>) return std::to_string(v);
        else return std::to_string(v);
    }, value);
}

inline Value parseValue(DataType type, const std::string &text) {
    std::size_t used = 0;
    switch (type) {
    case DataType::Bool:
        if (text == "true" || text == "1") return true;
        if (text == "false" || text == "0") return false;
        break;
    case DataType::Int32: {
        const auto v = std::stoll(text, &used);
        if (used == text.size() && v >= INT32_MIN && v <= INT32_MAX)
            return static_cast<std::int32_t>(v);
        break;
    }
    case DataType::UInt32: {
        const auto v = std::stoull(text, &used);
        if (used == text.size() && v <= UINT32_MAX) return static_cast<std::uint32_t>(v);
        break;
    }
    case DataType::Int64: {
        const auto v = std::stoll(text, &used);
        if (used == text.size()) return static_cast<std::int64_t>(v);
        break;
    }
    case DataType::UInt64: {
        const auto v = std::stoull(text, &used);
        if (used == text.size()) return static_cast<std::uint64_t>(v);
        break;
    }
    case DataType::Float32: {
        const auto v = std::stof(text, &used);
        if (used == text.size() && std::isfinite(v)) return v;
        break;
    }
    case DataType::Float64: {
        const auto v = std::stod(text, &used);
        if (used == text.size() && std::isfinite(v)) return v;
        break;
    }
    }
    throw std::runtime_error("invalid value '" + text + "' for " + toString(type));
}

struct PointConfig {
    std::uint32_t id{};
    std::uint32_t systemPointId{};
    std::string name;
    DataType dataType{};
    std::string direction;
    Value initialValue{};
    bool enabled{};
};

struct BindingConfig {
    std::uint32_t pointId{};
    std::string alias;
    std::string accessMode;
    double deadband{};
};

struct TaskConfig {
    std::uint32_t id{};
    std::string name;
    std::string scriptPath;
    std::string entryFunction;
    std::string triggerType;
    std::uint32_t intervalMs{};
    std::uint32_t timeoutMs{};
    std::string restartPolicy;
    bool enabled{};
    std::vector<BindingConfig> bindings;
};

struct RuntimeConfig {
    std::uint32_t versionId{};
    std::uint32_t versionNo{};
    std::string contentHash;
    std::vector<PointConfig> points;
    std::vector<TaskConfig> tasks;
};

} // namespace demo
