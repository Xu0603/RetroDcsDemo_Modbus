#pragma once

#include "common/types.hpp"

#include <string>

struct sqlite3;

namespace demo {

class ConfigRepository {
public:
    explicit ConfigRepository(std::string path);
    ~ConfigRepository();
    ConfigRepository(const ConfigRepository &) = delete;
    ConfigRepository &operator=(const ConfigRepository &) = delete;

    void open();
    RuntimeConfig loadPublished();
    static void validate(const RuntimeConfig &config, const std::string &scriptsRoot);

private:
    std::string path_;
    sqlite3 *db_{};
};

} // namespace demo
