#include "manager/config_repository.hpp"
#include "manager/ipc_protocol.hpp"
#include "manager/shared_memory.hpp"

#include <cmath>
#include <iostream>
#include <stdexcept>
#include <string>
#include <unistd.h>

namespace {

void require(bool condition, const std::string &message) {
    if (!condition) throw std::runtime_error(message);
}

} // namespace

int main(int argc, char **argv) {
    using namespace demo;
    try {
        if (argc != 2) throw std::runtime_error("database path required");
        ConfigRepository repository(argv[1]);
        repository.open();
        const auto config = repository.loadPublished();
        require(config.versionNo == 1, "wrong config version");
        require(config.points.size() == 3, "wrong point count");
        require(config.tasks.size() == 1, "wrong task count");
        require(config.tasks[0].bindings.size() == 3, "wrong binding count");

        const std::string shmName = "/pycom_component_" + std::to_string(getpid());
        SharedMemoryManager shm(shmName, config.versionNo, config.points);
        shm.create();
        auto before = shm.read(3);
        require(std::abs(std::get<double>(before.value)) < 1e-12, "wrong initial value");
        shm.write(3, 15.48, PointStatus::Good);
        auto after = shm.read(3);
        require(std::abs(std::get<double>(after.value) - 15.48) < 1e-12, "shared memory write failed");
        require(after.sequence > before.sequence && after.sequence % 2 == 0, "invalid sequence");

        Message original{{"type", "SCRIPT_LOG"}, {"message", "中文=value\nnext"}};
        require(decodeMessage(encodeMessage(original)) == original, "IPC codec roundtrip failed");
        std::cout << "component tests passed\n";
        return 0;
    } catch (const std::exception &e) {
        std::cerr << "component tests failed: " << e.what() << '\n';
        return 1;
    }
}
