#!/usr/bin/env python3
from pathlib import Path
import json
import os
import socket
import struct
import subprocess
import sys
import time


def request(message_type: int, request_id: int = 1) -> dict:
    payload = b"{}"
    frame = struct.pack("!4sHHII", b"PYSM", 1, message_type, request_id, len(payload)) + payload
    with socket.create_connection(("127.0.0.1", 19090), timeout=1.0) as connection:
        connection.sendall(frame)
        header = connection.recv(16)
        if len(header) != 16:
            raise RuntimeError("short TCP response header")
        magic, version, response_type, response_id, length = struct.unpack("!4sHHII", header)
        if magic != b"PYSM" or version != 1 or response_id != request_id:
            raise RuntimeError("invalid TCP response header")
        body = b""
        while len(body) < length:
            chunk = connection.recv(length - len(body))
            if not chunk:
                raise RuntimeError("short TCP response body")
            body += chunk
        return json.loads(body)


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    subprocess.run([sys.executable, str(root / "tools" / "create_demo_db.py")], check=True)
    manager = subprocess.Popen([
        str(root / "build" / "system-managerd"),
        "--database", str(root / "database" / "demo.sqlite"),
        "--scripts-root", str(root / "scripts" / "examples"),
        "--shm-name", f"/pycom_tcp_{os.getpid()}",
        "--log", str(root / "run" / "tcp-test.log"),
        "--python", sys.executable,
        "--run-seconds", "5",
    ])
    try:
        deadline = time.monotonic() + 3.0
        while True:
            try:
                ping = request(1)
                break
            except OSError:
                if time.monotonic() >= deadline:
                    raise
                time.sleep(0.05)
        if not ping.get("ok") or ping.get("configVersion") != 1:
            raise RuntimeError(f"unexpected PING response: {ping}")
        time.sleep(1.3)
        snapshot = request(2, 2)
        points = {point["name"]: point for point in snapshot["points"]}
        if set(points) != {"temperature", "pressure", "calculated_value"}:
            raise RuntimeError(f"unexpected point list: {points}")
        if abs(float(points["calculated_value"]["value"]) - 15.48) > 1e-6:
            raise RuntimeError("TCP snapshot has wrong calculated value")
        print("TCP query test passed")
        return 0
    finally:
        if manager.poll() is None:
            manager.terminate()
        manager.wait(timeout=3)


if __name__ == "__main__":
    raise SystemExit(main())
