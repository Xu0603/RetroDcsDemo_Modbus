PRAGMA foreign_keys = ON;
PRAGMA journal_mode = WAL;

CREATE TABLE IF NOT EXISTS schema_version (
    version INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS config_version (
    id INTEGER PRIMARY KEY,
    version_no INTEGER NOT NULL UNIQUE,
    status TEXT NOT NULL CHECK(status IN ('DRAFT','PUBLISHED','ARCHIVED')),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    content_hash TEXT NOT NULL
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_one_published
ON config_version(status) WHERE status = 'PUBLISHED';

CREATE TABLE IF NOT EXISTS point (
    id INTEGER PRIMARY KEY,
    version_id INTEGER NOT NULL REFERENCES config_version(id),
    system_point_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    data_type TEXT NOT NULL CHECK(data_type IN
        ('BOOL','INT32','UINT32','INT64','UINT64','FLOAT32','FLOAT64')),
    direction TEXT NOT NULL CHECK(direction IN ('INPUT','OUTPUT','BIDIRECTIONAL')),
    initial_value TEXT NOT NULL DEFAULT '0',
    enabled INTEGER NOT NULL DEFAULT 1 CHECK(enabled IN (0,1)),
    UNIQUE(version_id, system_point_id),
    UNIQUE(version_id, name)
);

CREATE TABLE IF NOT EXISTS python_task (
    id INTEGER PRIMARY KEY,
    version_id INTEGER NOT NULL REFERENCES config_version(id),
    name TEXT NOT NULL,
    script_path TEXT NOT NULL,
    entry_function TEXT NOT NULL DEFAULT 'on_timer',
    trigger_type TEXT NOT NULL CHECK(trigger_type IN ('PERIODIC','POINT_CHANGE','MANUAL')),
    interval_ms INTEGER NOT NULL DEFAULT 1000 CHECK(interval_ms >= 10),
    timeout_ms INTEGER NOT NULL DEFAULT 1000 CHECK(timeout_ms >= 10),
    restart_policy TEXT NOT NULL DEFAULT 'ON_FAILURE'
        CHECK(restart_policy IN ('NEVER','ON_FAILURE','ALWAYS')),
    enabled INTEGER NOT NULL DEFAULT 1 CHECK(enabled IN (0,1)),
    UNIQUE(version_id, name)
);

CREATE TABLE IF NOT EXISTS python_binding (
    id INTEGER PRIMARY KEY,
    task_id INTEGER NOT NULL REFERENCES python_task(id) ON DELETE CASCADE,
    point_id INTEGER NOT NULL REFERENCES point(id),
    alias TEXT NOT NULL,
    access_mode TEXT NOT NULL CHECK(access_mode IN ('READ','WRITE','READ_WRITE')),
    deadband REAL NOT NULL DEFAULT 0.0 CHECK(deadband >= 0),
    enabled INTEGER NOT NULL DEFAULT 1 CHECK(enabled IN (0,1)),
    UNIQUE(task_id, alias),
    UNIQUE(task_id, point_id)
);
