DELETE FROM python_binding;
DELETE FROM python_task;
DELETE FROM point;
DELETE FROM config_version;
DELETE FROM schema_version;

INSERT INTO schema_version(version) VALUES (1);
INSERT INTO config_version(id, version_no, status, content_hash)
VALUES (1, 1, 'PUBLISHED', 'demo-v1');

INSERT INTO point(id, version_id, system_point_id, name, data_type, direction, initial_value)
VALUES
    (1, 1, 1001, 'temperature',      'FLOAT64', 'INPUT',  '25.0'),
    (2, 1, 1002, 'pressure',         'FLOAT64', 'INPUT',  '1.2'),
    (3, 1, 1003, 'calculated_value', 'FLOAT64', 'OUTPUT', '0.0');

INSERT INTO python_task(id, version_id, name, script_path, entry_function,
                        trigger_type, interval_ms, timeout_ms, restart_policy)
VALUES (1, 1, 'weighted_calculation', 'weighted_calculation.py', 'on_timer',
        'PERIODIC', 1000, 800, 'ON_FAILURE');

INSERT INTO python_binding(id, task_id, point_id, alias, access_mode)
VALUES
    (1, 1, 1, 'temperature',      'READ'),
    (2, 1, 2, 'pressure',         'READ'),
    (3, 1, 3, 'calculated_value', 'WRITE');
